package com.starhealth.ecommerce.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.starhealth.ecommerce.entity.User;

public interface Iuser extends JpaRepository<User, Integer> {
	
	@Query("select user from User user where userName=?1 AND role=?2" )
	public User getUserByName(String userName,String role);
}
