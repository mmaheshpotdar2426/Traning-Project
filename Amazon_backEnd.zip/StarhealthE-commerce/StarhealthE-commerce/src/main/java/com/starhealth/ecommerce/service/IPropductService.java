package com.starhealth.ecommerce.service;

import java.util.List;

import com.starhealth.ecommerce.entity.Product;

public interface IPropductService {
	
	public Product addProduct(Product prod);
	public Product updateProduct(Product prod);
	public Product getProductById(int id);
	public List<Product> getAllProducts();
	public void deleteProductById(int id);
	
	
}
