package com.starhealth.ecommerce.service;

import com.starhealth.ecommerce.entity.User;

public interface IuserService {

	public User addUser(User user);

	public User getUserByName(String userName, String Domin);

}
