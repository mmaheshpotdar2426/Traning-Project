package com.starhealth.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.ecommerce.entity.User;
import com.starhealth.ecommerce.repository.Iuser;
@Service
public class IuserServiceImp implements IuserService {
	@Autowired
	Iuser userrepo;

	@Override
	public User addUser(User user) {
		return userrepo.save(user);

	}

	@Override
	public User getUserByName(String userName, String Domin) {
		return userrepo.getUserByName(userName,Domin) ;
	}

}
